from django.db import models

# Create your models here.
class Blog(models.Model):
    title = models.CharField(max_length=200)
    writer = models.CharField(max_length=100)
    pub_date = models.DateTimeField()
    body = models.TextField()
    image = models.ImageField(upload_to = "blog/", blank = True, null = True )
    #upload_to = 업로드할 폴더를 지정하는 것!
    #upload_to = settings.py에 MEDIA_URL 로 지정해둔 media 폴더 안에 blog 폴더를 만들어서 관리하겠다는 설정


def _str_(self): 
    return self.title

def summary(self):
    return self.body[1:100]
    #100번째 인덱스까지 잘라주는 것이다(python slicing)
